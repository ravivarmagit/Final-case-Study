import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
 
  public Account = "Account";  
  public loggedIn = false;
  public isAdmin = false;
  constructor(private auth: AuthService) { }

  ngOnInit(): void {
    
    if (this.auth.isUserLoggedIn()) {
      this.loggedIn = true;
      // console.log("user login called on app component.ts data is"+ this.loggedIn)\
      this.Account = this.auth.LoggedInUser();
      this.isAdmin = this.auth.isAdmin(); 
    }
  
 }

}
