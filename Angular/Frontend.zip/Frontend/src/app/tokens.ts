export class Tokens {
    jwt = "";
    refreshToken = "";
}
