// import { HttpClientModule } from '@angular/common/http';
// import { ComponentFixture, TestBed } from '@angular/core/testing';
// import { MatBottomSheetModule } from '@angular/material/bottom-sheet';
// import { MatCardModule } from '@angular/material/card';
// import { AppRoutingModule } from '../app-routing.module';

// import { BottomComponent } from './bottom.component';

// describe('BottomComponent', () => {
//   let component: BottomComponent;
//   let fixture: ComponentFixture<BottomComponent>;

//   beforeEach(async () => {
//     await TestBed.configureTestingModule({
//         imports: [HttpClientModule,AppRoutingModule],
//       declarations: [ BottomComponent ]
//     })
//     .compileComponents();
//   });

//   beforeEach(() => {
//     fixture = TestBed.createComponent(BottomComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
