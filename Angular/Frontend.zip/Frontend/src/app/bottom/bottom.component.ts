import { Component, Inject, OnInit } from '@angular/core';
import { MatBottomSheetRef, MAT_BOTTOM_SHEET_DATA } from '@angular/material/bottom-sheet';
import { AuthService } from '../auth.service';
import { BasicUserDetails } from '../basic-user-details';
import { Coupon } from '../coupon';
import { BottomData } from '../home/home.component';
import { ProfileService } from '../profile.service';

@Component({
  selector: 'app-bottom',
  templateUrl: './bottom.component.html',
  styleUrls: ['./bottom.component.css']
})
export class BottomComponent implements OnInit {


  public isCouponClicked = false;
  public postUserdetail: any;

  profileser: any;
  username: any;
  email: any;
  cashbackPoints: any;
  preferences: any;
  gotlistOfCoupons: Array<Coupon> = [];

  constructor(public bottomRef: MatBottomSheetRef<BottomComponent>,
    private profileservice: ProfileService,
    private auth: AuthService,
    @Inject(MAT_BOTTOM_SHEET_DATA) public data: BottomData) { }

  ngOnInit(): void {
    if (this.auth.isUserLoggedIn()) {

      this.profileservice.getuserdetails().subscribe(data => {
        
        this.username = data.username;
        this.email = data.email;
        this.cashbackPoints = data.cashbackPoints;
        this.preferences = data.preferences;
        this.gotlistOfCoupons = data.listOfCoupons;
        
        //console.log(this.gotlistOfCoupons);
      
      })
      console.log(this.data.isused);
    }

    if (this.data.isused) {
      
      this.isCouponClicked = true;
    }
    console.log(this.data);



  }
  // onNoClick(): void {
  //   this.bottomRef.close();
  // }

  public getImg(provider: String) {
    return "assets/images/provider/" + provider + ".png";
  }
  public couponclick() {

    console.log(this.gotlistOfCoupons);

    let usedcoupon = new Coupon
      (this.data.id, this.data.provider, this.data.code, this.data.description, this.data.description)
      this.gotlistOfCoupons=this.gotlistOfCoupons||[];
    this.gotlistOfCoupons.push(usedcoupon);
    console.log("----------------------");

    let postData = new BasicUserDetails
      (this.username, this.email, this.cashbackPoints + 100, this.preferences, this.gotlistOfCoupons);

    console.log("post data -------------")
    console.log(postData);

    this.profileservice.postuserdetails(postData);

    console.log(this.gotlistOfCoupons);
    // console.log(this.profileservice.getloggedinUserDetails());
    this.isCouponClicked = true;
    //console.log(this.data.code+"    "+this.data.description+"  "+this.data.provider+" "+this.data.id);
  }













}
