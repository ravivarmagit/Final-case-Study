import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AuthService } from './auth.service';
import { BasicUserDetails } from './basic-user-details';
import { SignUpdetails } from './sign-updetails';

@Injectable({
  providedIn: 'root'
})
export class ProfileService {
  public var = "";
  loggedinUserDetails:any;

  username:any;
  email:any
  cashbackPoints:any;
  preferences:any;
  listOfCoupons:any;

  constructor(private http:HttpClient, private auth:AuthService) { }
  getuserdetails(){
    this.var = this.auth.LoggedInUser();
    return this.http.get<BasicUserDetails>("http://localhost:8081/user/user/getuser/"+this.var);
   }
   postuserdetails(updatedDetails:BasicUserDetails){
    let jwt_token = this.auth.getJwtToken();
    const headers = new HttpHeaders({Authorization:"Bearer "+jwt_token});

    this.var = this.auth.LoggedInUser();

    // console.log(this.http.post("http://localhost:8081/user/user/update",updatedDetails).subscribe());
    return this.http.post("http://localhost:8081/user/user/update",updatedDetails,{headers}).subscribe();

  }
  adduser(adduser:SignUpdetails){
    
    //const headers = new HttpHeaders({Authorization:"Bearer eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJhZG1pbiIsImV4cCI6MTYzMDQxOTU5MywiaWF0IjoxNjMwNDEyMzkzfQ.tu0pEvtfvT0w9NF3mHpFrDAkzUbTBHbaqO8yu0VZANjWt7tG4tL2mLrdm0AdIZt01D46kyN8yWfDnjI-7PJlS"});
    //return this.http.post("http://localhost:8080/user/user/add",adduser,{headers}).subscribe();
    return this.http.post("http://localhost:8081/user/user/add",adduser).subscribe();
  }


}
