import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminDealsComponent } from './admin-deals.component';

describe('AdminDealsComponent', () => {
  let component: AdminDealsComponent;
  let fixture: ComponentFixture<AdminDealsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
        imports: [HttpClientModule],
      declarations: [ AdminDealsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminDealsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('get deal', () => {
    expect(component).toBeTruthy();
  });
});
