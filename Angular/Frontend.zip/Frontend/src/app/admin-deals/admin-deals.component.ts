import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { CouponserviceService } from '../couponservice.service';
import { DeleteCouponComponent } from '../delete-coupon/delete-coupon.component';

@Component({
  selector: 'app-admin-deals',
  templateUrl: './admin-deals.component.html',
  styleUrls: ['./admin-deals.component.css']
})

export class AdminDealsComponent implements OnInit {
   public ListOfCoupons:any = [];
  constructor(private couponservice:CouponserviceService,private dialog : MatDialog, private _snackBar : MatSnackBar) { }

  ngOnInit(): void {this.couponservice.get().subscribe(response=>{
    this.ListOfCoupons = response;
    //console.log(JSON.stringify(response));
    console.log(this.ListOfCoupons);
  },
  error=>{
    console.log(error)
  })
}
get(){  
  this.couponservice.get().subscribe(response=>{
    this.ListOfCoupons = response;
    //console.log(JSON.stringify(response));
    console.log(this.ListOfCoupons);
  },
  error=>{
    console.log(error)
  })
}

delete(ID:String,i:number){
  let snackbarRef = this._snackBar.open("Are you sure want to Delete", "Confirm", { duration: 10000, panelClass: ["custom-style"] });
 
  snackbarRef.onAction().subscribe(
    () => {
      console.log("delete prompt")
      this.couponservice.deleteCoupon(ID).subscribe();
      this.ListOfCoupons.splice(i, 1);
      this._snackBar.open("Coupon is deleted", "OK", { duration: 2000, panelClass: ["custom-style"] });
    })



  // this.couponservice.deleteCoupon(ID).subscribe();
  // this.ListOfCoupons.splice(i,1);

 
  //window.location.reload();
}
// openDialog() {
//   this.dialog.open(DeleteCouponComponent);
// }


}
