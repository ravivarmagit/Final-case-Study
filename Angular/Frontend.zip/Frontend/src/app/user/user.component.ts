import { Component, OnInit } from '@angular/core';
import { ProfileService } from '../profile.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  username: any;
  email: any
  cashbackPoints: any;
  preferences: any;
  listOfCoupons: any;

  constructor(private profileService: ProfileService) { }

  ngOnInit(): void {
    this.profileService.getuserdetails().subscribe(data => {
      this.username = data.username;
      this.email = data.email;
      this.cashbackPoints = data.cashbackPoints;
      this.preferences = data.preferences;
      this.listOfCoupons = data.listOfCoupons;
    })
  }
}
