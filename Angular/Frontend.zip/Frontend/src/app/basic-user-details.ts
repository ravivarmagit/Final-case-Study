import { Coupon } from "./coupon";

export class BasicUserDetails {
        constructor(
            public username:String,
            public email:String,
            public cashbackPoints:number,
            public preferences:[],
            public listOfCoupons:Array<Coupon> =[]
        ){}


}
