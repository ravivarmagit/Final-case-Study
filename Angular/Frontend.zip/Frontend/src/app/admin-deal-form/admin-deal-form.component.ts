import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DealserviceService } from '../dealservice.service';

@Component({
  selector: 'app-admin-deal-form',
  templateUrl: './admin-deal-form.component.html',
  styleUrls: ['./admin-deal-form.component.css']
})
export class AdminDealFormComponent implements OnInit {

  public categories = ["Electronics","Fashion","Food","Travel","Medicine","Recharge","Website","Movies","Sport"]

  public adForm!: FormGroup;
  public submitted = false;
  public confirmed = false;

  constructor(private _fb:FormBuilder, private formservice:DealserviceService ) { }

  ngOnInit(): void {
    this.adForm = this._fb.group({
      provider:["",[Validators.required]],
      category:["",[Validators.required]],
      description:["",[Validators.required]],
      link:["",[Validators.required]]
    });
  
  }
  onsubmit(){
    this.submitted = true;
  }

  confirm(){
    this.confirmed = true;
    this.formservice.add(this.adForm.value);
  }

  cancel(){
    this.submitted = false;
  }





}
