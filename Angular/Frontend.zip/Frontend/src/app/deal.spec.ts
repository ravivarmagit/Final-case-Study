// import { Deal } from './deal';

// // describe('Deal', () => {
// //   it('should create an instance', () => {
// //     expect(new Deal()).toBeTruthy();
// //   });
// // });
