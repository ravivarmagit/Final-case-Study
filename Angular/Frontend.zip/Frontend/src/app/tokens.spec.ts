// import { Tokens } from './tokens';

// describe('Tokens', () => {
//   it('should create an instance', () => {
//     expect(new Tokens()).toBeTruthy();
//   });
// });
