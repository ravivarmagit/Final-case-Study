import { Component, OnInit } from '@angular/core';
import { AdminDealTableComponent } from '../admin-deal-table/admin-deal-table.component';
import { DealserviceService } from '../dealservice.service';

@Component({
  selector: 'app-delete-dialog',
  templateUrl: './delete-dialog.component.html',
  styleUrls: ['./delete-dialog.component.css']
})
export class DeleteDialogComponent implements OnInit {
  ListOfDeals:any = []
  constructor() { }

  ngOnInit(): void {
    
  }
  

}
