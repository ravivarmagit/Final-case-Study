import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { throwError } from 'rxjs';
import { Observable } from 'rxjs/internal/Observable';
import { Coupon } from './coupon';
import { AuthService } from './auth.service';


@Injectable({
  providedIn: 'root'
})
export class CouponserviceService {
    _url = "http://localhost:8081/coupons/coupons"; //for API gateway
 // _url = "http://localhost:8082/coupons";
  messageSuccess: boolean | undefined;

  public username = "ravi";
  public password = "ravi";
  
  constructor(private _http:HttpClient, private auth:AuthService) { }

  public add(c:Coupon){
    
    console.log(c);
    console.log(JSON.stringify(c));
    let jwt_token = this.auth.getJwtToken();
    //var cal =  this._http.post(this._url+"/add",c, { observe: 'response', responseType: 'text'}).subscribe();
    const headers = new HttpHeaders({ Authorization:"Bearer "+jwt_token});
    this._http.post(this._url+"/add",c,{headers}).subscribe();
  }

  public get(){
      var our =  this._http.get(this._url+"/list");
      console.log(our);
      return our;
  }

  public deleteCoupon(ID:String){
    console.log(this._url+"/delete/"+ID);
    let jwt_token = this.auth.getJwtToken();
    const headers = new HttpHeaders({Authorization:"Bearer "+jwt_token});;
    var our =  this._http.delete(this._url+"/delete/"+ID,{headers});
    console.log(our);
    return our;
  }
}
