import { Component, OnInit } from '@angular/core';
import { MatBottomSheet } from '@angular/material/bottom-sheet';
import { AuthService } from '../auth.service';
import { BottomComponent } from '../bottom/bottom.component';
import { Coupon } from '../coupon';
import { CouponserviceService } from '../couponservice.service';
import { DealserviceService } from '../dealservice.service';
import { ProfileService } from '../profile.service';



export interface BottomData {
 
  id: String | any ;
  provider: String;
  code: String;
  description: String;
  category: String;
  isused: Boolean;
}

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})



export class HomeComponent implements OnInit {
  public ListOfCoupons: any = [];
  public Listofdeals: any = [];
  gotlistOfCoupons: Array<Coupon> = [];

  id: String | undefined;
  provider: String | undefined;
  code: String | undefined;
  description: String | undefined;
  loggedIn: boolean | undefined;
  Account: any;
  isAdmin: any;

  constructor(private couponservice: CouponserviceService, private dealservice: DealserviceService,
    private _bottomSheet: MatBottomSheet, private Auth: AuthService, private profileser:ProfileService) { }




  ngOnInit(): void {
    if (this.Auth.isUserLoggedIn()) {
      this.profileser.getuserdetails().subscribe(data => {
        this.gotlistOfCoupons = data.listOfCoupons;
      })
    }
    this.couponservice.get().subscribe(response => {
      this.ListOfCoupons = response;
      console.log(this.ListOfCoupons);
    },
      error => {
        console.log(error)
      })

    this.dealservice.get().subscribe(response => {
      this.Listofdeals = response;
    },
      error => {
        console.log(error)
      })

      if (this.Auth.isUserLoggedIn()) {
        this.loggedIn = true;
        // console.log("user login called on app component.ts data is"+ this.loggedIn)\
        this.Account = this.Auth.LoggedInUser();
        this.isAdmin = this.Auth.isAdmin(); 
      }



  }
  public dealRedirect(link:any){
    window.open(link);
  }
  public getImg(provider: String) {
    return "assets/images/provider/" + provider + ".png";
  }
  public openBottomSheet(i: Coupon) {
    const bottomRef = this._bottomSheet.open(BottomComponent, {
      data: {
        id: i.id,
        provider: i.provider,
        code: i.code,
        description: i.description,
        category: i.category,
        isused: this.couponUsedChecker(i.id)
      }
    });
    //  bottomRef.afterClosed().subscribe(result => {
    //    //console.log('The dialog was closed');
    //    this.provider = result;
    //  });
    
  } 
  couponUsedChecker(inputid: any) {
    if (this.Auth.isUserLoggedIn()) {
      if (!this.Auth.isAdmin() && (this.gotlistOfCoupons != null))  {
        var result = this.gotlistOfCoupons.find(({ id }) => id == inputid);
        if (result) {
          return true;
        }
      }
    }
    return false;
  }

}
