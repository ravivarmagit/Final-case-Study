import { BasicUserDetails } from './basic-user-details';

// describe('BasicUserDetails', () => {
//   it('should create an instance', () => {
//     expect(new BasicUserDetails()).toBeTruthy();
//   });
// });
