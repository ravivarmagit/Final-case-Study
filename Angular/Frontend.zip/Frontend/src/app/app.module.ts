import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AdminComponent } from './admin/admin.component';
import { UserComponent } from './user/user.component';
import { AdminDealsAddComponent } from './admin-deals-add/admin-deals-add.component';
import { AdminDealsComponent } from './admin-deals/admin-deals.component';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MaterialModule } from './material/material.module';
import { HomeComponent } from './home/home.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { AdminDealFormComponent } from './admin-deal-form/admin-deal-form.component';
import { AdminDealTableComponent } from './admin-deal-table/admin-deal-table.component';
import { NavbarComponent } from './navbar/navbar.component';
import {MatIconModule} from '@angular/material/icon';
import { MatCard, MatCardModule } from '@angular/material/card';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import {MatButtonModule} from '@angular/material/button';
import {MatMenuModule} from '@angular/material/menu';
import {MatDividerModule} from '@angular/material/divider';
import {MatBottomSheetModule} from '@angular/material/bottom-sheet';
import {MatDialogModule} from '@angular/material/dialog';
import { BottomComponent } from './bottom/bottom.component';
import { CarouselComponent } from './carousel/carousel.component';
import {MatTableModule} from '@angular/material/table';
import { FooterComponent } from './footer/footer.component';
import { SignupComponent } from './signup/signup.component';
import { PaymentDialogComponent } from './payment-dialog/payment-dialog.component';
import { WalletComponent } from './wallet/wallet.component';
import { DeleteDialogComponent } from './delete-dialog/delete-dialog.component';
import { DeleteCouponComponent } from './delete-coupon/delete-coupon.component';
import {MatSnackBarModule} from '@angular/material/snack-bar';



@NgModule({
  declarations: [
    AppComponent,
    AdminComponent,
    UserComponent,
    AdminDealsAddComponent,
    AdminDealsComponent,
    HomeComponent,
    AboutusComponent,
    AdminDealFormComponent,
    AdminDealTableComponent,
    NavbarComponent,
    LoginComponent,
    LogoutComponent,
    BottomComponent,
    CarouselComponent,
    FooterComponent,
    SignupComponent,
    PaymentDialogComponent,
    WalletComponent,
    DeleteDialogComponent,
    DeleteCouponComponent

    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    ReactiveFormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    MaterialModule,
    MatIconModule,
    MatCardModule,
    FormsModule,
    MatButtonModule,
    MatMenuModule,
    MatDividerModule,
    MatBottomSheetModule,
    MatDialogModule,
    MatTableModule,
    MatSnackBarModule
    
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
