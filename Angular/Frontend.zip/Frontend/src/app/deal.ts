export class Deal {
    constructor(
        public provider:String,
        public category:String,
        public description:String,
        public link:String
    ){}
}
