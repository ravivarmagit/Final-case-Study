export class SignUpdetails {

    constructor(
        public username:String,
        public password:String,
        public email:String,
    ){}

}
