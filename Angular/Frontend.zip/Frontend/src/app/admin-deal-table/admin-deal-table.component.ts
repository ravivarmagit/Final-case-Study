import { Component, OnInit } from '@angular/core';
import { DealserviceService } from '../dealservice.service';
import { MatDialog } from '@angular/material/dialog';
import { DeleteDialogComponent } from '../delete-dialog/delete-dialog.component';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-admin-deal-table',
  templateUrl: './admin-deal-table.component.html',
  styleUrls: ['./admin-deal-table.component.css']
})
export class AdminDealTableComponent implements OnInit {
  ListOfDeals:any = []

  constructor(private dealservice:DealserviceService, private dialog : MatDialog,private _snackBar : MatSnackBar) { }

  ngOnInit(): void {
    this.dealservice.get().subscribe(response=>{
      this.ListOfDeals = response;
    },
    error=>{
      console.log(error)
    })

  }
  delete(ID:String,i:number){
    // console.log(ID);
    let snackbarRef = this._snackBar.open("Are you sure want to Delete", "Confirm", { duration: 10000, panelClass: ["custom-style"] });
    snackbarRef.onAction().subscribe(
      () => {
        console.log("delete prompt")
        this.dealservice.deleteDeal(ID).subscribe();
        this.ListOfDeals.splice(i, 1);
        this._snackBar.open("Deal is deleted", "OK", { duration: 2000, panelClass: ["custom-style"] });
      })
      


    // this.dealservice.deleteDeal(ID).subscribe();
    // this.ListOfDeals.splice(i,1);
    

  }
  // openDialog() {
  //   this.dialog.open(DeleteDialogComponent);
  // }

}
