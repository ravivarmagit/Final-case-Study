import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterModule } from '@angular/router';

import { AdminDealTableComponent } from './admin-deal-table.component';

describe('AdminDealTableComponent', () => {
  let component: AdminDealTableComponent;
  let fixture: ComponentFixture<AdminDealTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
        imports:[HttpClientModule, RouterModule],
      declarations: [ AdminDealTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminDealTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('is admin', () => {
    expect(component).toBeTruthy();
  });

  
});
