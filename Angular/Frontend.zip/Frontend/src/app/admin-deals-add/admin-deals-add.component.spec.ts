// import { ComponentFixture, TestBed } from '@angular/core/testing';

// import { AdminDealsAddComponent } from './admin-deals-add.component';

// describe('AdminDealsAddComponent', () => {
//   let component: AdminDealsAddComponent;
//   let fixture: ComponentFixture<AdminDealsAddComponent>;

//   beforeEach(async () => {
//     await TestBed.configureTestingModule({
//       declarations: [ AdminDealsAddComponent ]
//     })
//     .compileComponents();
//   });

//   beforeEach(() => {
//     fixture = TestBed.createComponent(AdminDealsAddComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });

// it("Testing catagories",()=>{
//      expect(AdminDealsAddComponent.categories.length).toBe(9)
//      });

