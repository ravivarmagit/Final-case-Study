import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AuthService } from './auth.service';
import { Deal } from './deal';

@Injectable({
  providedIn: 'root'
})
export class DealserviceService {

  _url = "http://localhost:8081/deals/deals";
  
  public username = "ravi";
  public password = "ravi";

  
  
  constructor(private _http:HttpClient, private auth : AuthService) { }

  public add(d:Deal){
    let jwt_token = this.auth.getJwtToken();
    const headers = new HttpHeaders({ Authorization:"Bearer "+jwt_token});
    this._http.post(this._url+"/add",d,{headers}).subscribe();

  }

  public get(){
      var our =  this._http.get(this._url+"/list");
      console.log(our);
      return our;
  }

  public deleteDeal(ID:String){
    let jwt_token = this.auth.getJwtToken();
    const headers = new HttpHeaders({Authorization:"Bearer "+jwt_token});
    console.log(this._url+"/delete/"+ID);
    var our =  this._http.delete(this._url+"/delete/"+ID,{headers});
    console.log(our);
    return our;
  }







  
}
