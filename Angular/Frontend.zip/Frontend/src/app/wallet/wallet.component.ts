import { Component, OnInit } from '@angular/core';
import { BasicUserDetails } from '../basic-user-details';
import { ProfileService } from '../profile.service';

@Component({
  selector: 'app-wallet',
  templateUrl: './wallet.component.html',
  styleUrls: ['./wallet.component.css']
})
export class WalletComponent implements OnInit {
  
  public isWallet = false;
  public isInsufficient = false;
  public addAmount = false;

  constructor(private profileService: ProfileService) { }
  username: any;
  email: any
  cashbackPoints: any;
  preferences: any;
  listOfCoupons: any;
  redeem = 0;
  

  ngOnInit(): void {
    this.profileService.getuserdetails().subscribe(data => {
      this.username = data.username;
      this.email = data.email;
      this.cashbackPoints = data.cashbackPoints;
      this.preferences = data.preferences;
      this.listOfCoupons = data.listOfCoupons;
    })
     
  }
  useredeem() {

   
    

    if (this.redeem < this.cashbackPoints ) {
      console.log(this.cashbackPoints);
      this.isWallet=true;
      this.isInsufficient=false;
      this.cashbackPoints = this.cashbackPoints - this.redeem;

      let postData = new BasicUserDetails
        (this.username,
          this.email,
          this.cashbackPoints,
          this.preferences,
          this.listOfCoupons);
        
      this.profileService.postuserdetails(postData);

     
    }
     
    else{ this.isInsufficient = true; 
          this.isWallet = false
          }


   
    
      
    
  }

  



 }




