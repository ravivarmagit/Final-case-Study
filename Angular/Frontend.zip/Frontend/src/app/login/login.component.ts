import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../auth.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  
  username = "";
  password = "";
  invalidLogin = false;
  msg : any

  constructor( 
    private auth:AuthService,
    private router:Router,
    private route: ActivatedRoute) { }

    
  ngOnInit(): void {
    // this.msg = Number(this.route.snapshot.paramMap.get("msg"));
    // if(this.msg === "restricted"){this.invalidLogin = true}
    // console.log(this.msg);
  }
  nav() { this.router.navigateByUrl(""); }

  login() {
    this.auth.login(
      {
        
        username: this.username,
        password: this.password
      }
    )
        
      .subscribe(success => {
        if (success) {
          console.log("ered" +this.auth.LoggedInUser())
         this.router.navigate(["home"]); 
        }
      });
  }
}

