import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ProfileService } from '../profile.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  public adForm!: FormGroup;
  public submitted = false;
  public confirmed = false;

  constructor(private _fb:FormBuilder,
     private profileservice:ProfileService,
     private router:Router
     ) { }

  ngOnInit(): void {
    this.adForm = this._fb.group({
      username:["",[Validators.required]],
      password:["",[Validators.required]],
      email:["",[Validators.email]]
    });
  }

    onsubmit(){
    this.confirmed = true;
    this.profileservice.adduser(this.adForm.value);
    // this.router.navigate(["login","registration"])
    console.log(this.adForm.value);
    this.router.navigateByUrl("/login");
  }
}
