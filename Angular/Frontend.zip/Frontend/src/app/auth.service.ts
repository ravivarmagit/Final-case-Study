import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { of,Observable } from 'rxjs';
import { catchError, mapTo, tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  // credentials = [{"username":"ravi","password":"ravi"},{"username":"admin","password":"admin"}];

  _url = "http://localhost:8081/gateway"; //API gateway

  private readonly JWT_TOKEN = 'JWT_TOKEN';
  private readonly REFRESH_TOKEN = 'REFRESH_TOKEN';
  private loggedUser: any;
  private isloggsuccess = false;


  constructor(private http: HttpClient) { }

  login(user: { username: string, password: string }): Observable<boolean> {
    return this.http.post<any>(this._url + "/authenticate", user)
      .pipe(
        tap(tokens => this.doLoginUser(user.username, tokens.jwtToken)),
        mapTo(true),
        catchError(error => {
          alert("Username or password Incorrect");
          return of(false);
          
        }));
  }
  logout() {
    this.doLogoutUser();
  }

  isLoggedIn() {
    return !!this.getJwtToken();
  }


  getJwtToken() {
    console.log(localStorage.getItem(this.JWT_TOKEN));
    return localStorage.getItem(this.JWT_TOKEN);
  }

  private doLoginUser(username: string, tokens: String) {
    //console.log("user logged in is: "+username);
    //console.log("tokes: "+tokens);
    this.loggedUser = username;
    this.isloggsuccess = true;
    this.storeTokens(tokens);
  }
  
  private doLogoutUser() {
    this.loggedUser = null;
    this.isloggsuccess = false;
    this.removeTokens();
  }

  private storeTokens(tokens: any) {
    localStorage.setItem(this.JWT_TOKEN, tokens);
  }

  private removeTokens() {
    localStorage.removeItem(this.JWT_TOKEN);
  }

  isUserLoggedIn() {
    return this.isloggsuccess;
  }

  LoggedInUser() {
    
    return this.loggedUser;
  }

  isAdmin() {
    if (this.loggedUser == "admin") { return true; } return false;
  }
  





  


}
