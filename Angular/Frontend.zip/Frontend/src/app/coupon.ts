export class Coupon {
    constructor(
        public id : string,
        public provider:String,
        public code:String,
        public category:String,
        public description:String
    ){}
}

 