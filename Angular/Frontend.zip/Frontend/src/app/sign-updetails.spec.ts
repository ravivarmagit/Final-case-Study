// import { SignUpdetails } from './sign-updetails';

// describe('SignUpdetails', () => {
//   it('should create an instance', () => {
//     expect(new SignUpdetails()).toBeTruthy();
//   });
// });
