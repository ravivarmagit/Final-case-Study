import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-delete-coupon',
  templateUrl: './delete-coupon.component.html',
  styleUrls: ['./delete-coupon.component.css']
})
export class DeleteCouponComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
