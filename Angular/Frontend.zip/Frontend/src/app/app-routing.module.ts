import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutusComponent } from './aboutus/aboutus.component';
import { AdminDealFormComponent } from './admin-deal-form/admin-deal-form.component';
import { AdminDealTableComponent } from './admin-deal-table/admin-deal-table.component';
import { AdminDealsAddComponent } from './admin-deals-add/admin-deals-add.component';
import { AdminDealsComponent } from './admin-deals/admin-deals.component';
import { AdminComponent } from './admin/admin.component';
import { AuthGuardService } from './auth-guard.service';
import { CouponsComponent } from './coupons/coupons.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { PaymentDialogComponent } from './payment-dialog/payment-dialog.component';
import { SignupComponent } from './signup/signup.component';
import { UserComponent } from './user/user.component';
import { WalletComponent } from './wallet/wallet.component';

const routes: Routes = [
  {path: 'adminDealsAdd', component:AdminDealsAddComponent,canActivate:[AuthGuardService]},
  {path: 'adminDeals', component:AdminDealsComponent,canActivate:[AuthGuardService]},
  {path: 'home', component:HomeComponent},
  {path: 'admin', component:AdminComponent},
  {path: 'user', component:UserComponent},
  {path: 'coupons', component:CouponsComponent},
  {path: 'aboutUs', component:AboutusComponent},
  {path: 'adminDealform', component:AdminDealFormComponent,canActivate:[AuthGuardService]},
  {path: 'adminDealtable', component:AdminDealTableComponent,canActivate:[AuthGuardService]},
  {path: 'login', component:LoginComponent},
  {path:'logout', component:LogoutComponent},
  {path:'',component:HomeComponent, pathMatch: 'full' },
  {path:'UserProfile',component:UserComponent},
  {path: 'aboutus', component:AboutusComponent},
  {path: 'signup', component:SignupComponent},
  {path: 'payment', component:WalletComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
